package edu.bu.metcs.portal;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button portalBtn;
    private Button projectBtn;
    private Button noteBtn;
    private Button favoriteBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        portalBtn = findViewById(R.id.portal_btn);
        projectBtn = findViewById(R.id.project_btn);
        favoriteBtn = findViewById(R.id.favorite_btn);
        noteBtn = findViewById(R.id.note_btn);

        portalBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, PortalUI.class);
                intent.putExtra(PortalUI.EXTRA_EDIT_PORTAL, "YES");
                startActivity(intent);
            }
        });

        projectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ProjectUI.class);
                startActivity(intent);
            }
        });
        favoriteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, FavoriteUI.class);
                startActivity(intent);
            }
        });
        noteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NoteUI.class);
                startActivity(intent);
            }
        });


    }

}
