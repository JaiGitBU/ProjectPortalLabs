package edu.bu.metcs.portal;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import java.util.ArrayList;
import java.util.List;

public class PortalRepository {
    private PortalDao portalDao;
    private LiveData<List<Portal>> allPortals;
    private ArrayList<String> portalTitles;


    public PortalRepository(Application application) {
        PortalDataBase portalDataBase = PortalDataBase.getInstance(application);
        portalDao = portalDataBase.portalDao();
        allPortals = portalDao.getAllPortals();


    }

    public void insert(Portal portal) {
        new InsertAsyncTask(portalDao).execute(portal);

    }

    public void update(Portal portal) {
        new UpdateAsyncTask(portalDao).execute(portal);

    }

    public void delete(Portal portal) {
        new DeleteAsyncTask(portalDao).execute(portal);
    }

    public void deleteAllPortals() {
        new DeleteAllPortalsAsyncTask(portalDao).execute();
    }

    public LiveData<List<Portal>> getAllPortals() {
        return allPortals;
    }


    private static class InsertAsyncTask extends AsyncTask<Portal, Void, Void> {
        private PortalDao portalDao;

        private InsertAsyncTask(PortalDao portalDao) {
            this.portalDao = portalDao;
        }

        @Override
        protected Void doInBackground(Portal... portals) {
            portalDao.insert(portals[0]);
            return null;
        }

    }

    private static class UpdateAsyncTask extends AsyncTask<Portal, Void, Void> {
        private PortalDao portalDao;

        private UpdateAsyncTask(PortalDao portalDao) {
            this.portalDao = portalDao;
        }

        @Override
        protected Void doInBackground(Portal... portals) {
            portalDao.update(portals[0]);
            return null;
        }

    }

    private static class DeleteAsyncTask extends AsyncTask<Portal, Void, Void> {
        private PortalDao portalDao;

        private DeleteAsyncTask(PortalDao portalDao) {
            this.portalDao = portalDao;
        }

        @Override
        protected Void doInBackground(Portal... portals) {
            portalDao.delete(portals[0]);
            return null;
        }

    }


    private static class DeleteAllPortalsAsyncTask extends AsyncTask<Void, Void, Void> {
        private PortalDao portalDao;

        private DeleteAllPortalsAsyncTask(PortalDao portalDao) {
            this.portalDao = portalDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            portalDao.deleteAllPortals();
            return null;
        }

    }
}
