package edu.bu.metcs.portal;

import android.support.annotation.NonNull;
import android.support.v7.recyclerview.extensions.ListAdapter;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import edu.bu.metcs.portal.R;

public class NoteAdapter extends ListAdapter<Note, NoteAdapter.NoteHolder> {


    private OnItemClickedListner listner;

    public NoteAdapter() {
        super(DIFF_CALLBACK);

    }

    private static final DiffUtil.ItemCallback<Note> DIFF_CALLBACK = new DiffUtil.ItemCallback<Note>() {
        @Override
        public boolean areItemsTheSame(@NonNull Note oldNote, @NonNull Note newNote) {
            return oldNote.getNoteId() == newNote.getNoteId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Note oldNote, @NonNull Note newNote) {
            return oldNote.getProjectId() == (newNote.getProjectId())
                    && oldNote.getNoteTitle().equals(newNote.getNoteTitle())
                    && oldNote.getNote().equals(newNote.getNote());
        }
    };

    @NonNull
    @Override
    public NoteAdapter.NoteHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.note_item, parent, false);
        return new NoteHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteAdapter.NoteHolder holder, int position) {
        Note curNote = getItem(position);
        holder.textViewCourseFid.setText(String.valueOf(curNote.getProjectId()));
        holder.textViewNoteTitle.setText(curNote.getNoteTitle());
        holder.textViewNote.setText(curNote.getNote());


    }

    public Note getNoteAt(int position) {
        return getItem(position);
    }

    class NoteHolder extends RecyclerView.ViewHolder {
        private TextView textViewCourseFid;
        private TextView textViewNoteTitle;
        private TextView textViewNote;

        public NoteHolder(View itemView) {
            super(itemView);
            textViewCourseFid = itemView.findViewById(R.id.coursefid_view);
            textViewNoteTitle = itemView.findViewById(R.id.note_title_view);
//            textViewNote = itemView.findViewById(R.id.note_content_view);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (listner != null && position != RecyclerView.NO_POSITION) {
                        listner.onItemClicked(getItem(position));
                    }
                }
            });


        }
    }

    public interface OnItemClickedListner {
        void onItemClicked(Note note);

    }

    public void setOnItemClickedListner(OnItemClickedListner listner) {
        this.listner = listner;
    }
}
