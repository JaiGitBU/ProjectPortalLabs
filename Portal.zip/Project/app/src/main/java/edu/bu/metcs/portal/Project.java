package edu.bu.metcs.portal;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;

@Entity(tableName = "projects")
public class Project {
    @PrimaryKey(autoGenerate = true)
    private int projectId;
    @ForeignKey(entity = Portal.class, parentColumns = "portalId", childColumns = "portalId")
    private int portalId;
    private String projectTitle;
    private String projectDescription;
    private String isFavorite;
    private String keywords;
    private String authors;
    private String link;

    @Ignore
    public Project() {
    }

    public Project(int portalId, String projectTitle, String projectDescription, String isFavorite, String keywords,
                   String authors, String link) {
        this.portalId = portalId;
        this.projectTitle = projectTitle;
        this.projectDescription = projectDescription;
        this.isFavorite = isFavorite;
        this.keywords = keywords;
        this.authors = authors;
        this.link = link;
    }

    @Ignore
    public Project(int projectId, int portalId, String projectTitle, String projectDescription, String isFavorite, String keywords,
                   String authors, String link) {
        this.projectId = projectId;
        this.portalId = portalId;
        this.projectTitle = projectTitle;
        this.projectDescription = projectDescription;
        this.isFavorite = isFavorite;
        this.keywords = keywords;
        this.authors = authors;
        this.link = link;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public int getPortalId() {
        return portalId;
    }

    public void setPortalId(int portalId) {
        this.portalId = portalId;
    }

    public String getProjectTitle() {
        return projectTitle;
    }

    public void setProjectTitle(String projectTitle) {
        this.projectTitle = projectTitle;
    }

    public String getProjectDescription() {
        return projectDescription;
    }

    public void setProjectDescription(String projectDescription) {
        this.projectDescription = projectDescription;
    }

    public String getIsFavorite() {
        return isFavorite;
    }

    public void setIsFavorite(String isFavorite) {
        this.isFavorite = isFavorite;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }


    public String getLink() {
        return link;
    }

    public void setlink(String link) {
        this.link = link;
    }


    @Override
    public String toString() {
        return "Course{" +
                "projectId=" + projectId +
                ",portalId=" + portalId +
                ", projectTitle='" + projectTitle + '\'' +
                ", projectDescription='" + projectDescription + '\'' +
                ", isFavorite='" + isFavorite + '\'' +
                ", keywords='" + keywords + '\'' +
                ", authors='" + authors + '\'' +
                ", link='" + link + '\'' +
                '}';
    }
}

