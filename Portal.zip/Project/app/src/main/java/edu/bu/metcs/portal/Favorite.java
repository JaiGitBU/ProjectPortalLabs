package edu.bu.metcs.portal;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;


@Entity(tableName = "favorites")
public class Favorite {
    @PrimaryKey(autoGenerate = true)
    private int favoriteId;
    @ForeignKey(entity = Project.class,
            parentColumns = "projectId",
            childColumns = "projectId")
    private int projectId;
    private String favoriteTitle;


    @Ignore
    public Favorite() {
    }

    public Favorite(int projectId, String favoriteTitle) {
        this.projectId = projectId;
        this.favoriteTitle = favoriteTitle;
    }

    @Ignore
    public Favorite(int favoriteId, int projectId, String favoriteTitle) {
        this.favoriteId = favoriteId;
        this.projectId = projectId;
        this.favoriteTitle = favoriteTitle;

    }

    public int getFavoriteId() {
        return favoriteId;
    }

    public void setFavoriteId(int favoriteId) {
        this.favoriteId = favoriteId;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getFavoriteTitle() {
        return favoriteTitle;
    }

    public void setFavoriteTitle(String favoriteTitle) {
        this.favoriteTitle = favoriteTitle;
    }


    @Override
    public String toString() {
        return "Favorite{" +
                "favoriteId=" + favoriteId +
                ", projectId=" + projectId +
                ", favoriteTitle='" + favoriteTitle + '\'' +
                '}';
    }
}
