package edu.bu.metcs.portal;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import java.util.List;

public class FavoriteView extends AndroidViewModel {
    private FavoriteRepository repository;
    private LiveData<List<Favorite>> allFavorites;

    private LiveData<List<Favorite>> allAssociatedFavorites;

    public FavoriteView(@NonNull Application application) {
        super(application);
        repository = new FavoriteRepository(application);
        allFavorites = repository.getAllFavorites();

    }

    public void insert(Favorite favorite) {
        repository.insert(favorite);
    }

    public void update(Favorite favorite) {
        repository.update(favorite);
    }

    public void delete(Favorite favorite) {
        repository.delete(favorite);
    }

    public void deleteAllFavorites() {
        repository.deleteAllFavorites();
    }

    public LiveData<List<Favorite>> getAllFavorites() {
        return allFavorites;
    }

    public LiveData<List<Favorite>> getAllAssociatedFavorites(int projectId) {
        allAssociatedFavorites = repository.getAllAssociatedFavorites(projectId);
        return allAssociatedFavorites;
    }

}