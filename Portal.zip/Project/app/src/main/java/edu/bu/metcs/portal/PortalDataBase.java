package edu.bu.metcs.portal;

import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;
import android.os.AsyncTask;
import android.support.annotation.NonNull;

@Database(entities = {Portal.class, Project.class, Note.class, Favorite.class}, version = 13, exportSchema = false)
public abstract class PortalDataBase extends RoomDatabase {
    private static PortalDataBase instance;

    public abstract PortalDao portalDao();

    public abstract ProjectDao projectDao();

    public abstract NoteDao noteDao();

    public abstract FavoriteDao favoriteDao();

    public static synchronized PortalDataBase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    PortalDataBase.class, "PortalDB")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }

    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);

            new PopulateDbAsyncTask(instance).execute();
        }

        @Override
        public void onOpen(@NonNull SupportSQLiteDatabase db) {
            super.onOpen(db);
        }
    };

    private static class PopulateDbAsyncTask extends AsyncTask<Void, Void, Void> {
        private PortalDao portalDao;

        private PopulateDbAsyncTask(PortalDataBase portalDataBase) {
            portalDao = portalDataBase.portalDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            portalDao.insert(new Portal("Portal-1"));
            return null;
        }
    }
}
