package edu.bu.metcs.portal;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;


@Entity(tableName = "notes")
public class Note {
    @PrimaryKey(autoGenerate = true)
    private int noteId;
    @ForeignKey(entity = Project.class,
            parentColumns = "courseId",
            childColumns = "courseId")
    private int projectId;
    private String noteTitle;
    private String note;


    @Ignore
    public Note() {
    }

    public Note(int projectId, String noteTitle, String note) {
        this.projectId = projectId;
        this.noteTitle = noteTitle;
        this.note = note;
    }

    @Ignore
    public Note(int noteId, int projectId, String noteTitle, String note) {
        this.noteId = noteId;
        this.projectId = projectId;
        this.noteTitle = noteTitle;
        this.note = note;
    }

    public int getNoteId() {
        return noteId;
    }

    public void setNoteId(int noteId) {
        this.noteId = noteId;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getNoteTitle() {
        return noteTitle;
    }

    public void setNoteTitle(String noteTitle) {
        this.noteTitle = noteTitle;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Override
    public String toString() {
        return "Note{" +
                "noteId=" + noteId +
                ", projectId=" + projectId +
                ", note='" + note + '\'' +
                ", noteTitle='" + noteTitle + '\'' +
                '}';
    }

}
