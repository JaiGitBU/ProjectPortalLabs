package edu.bu.metcs.portal;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import java.util.List;

public class FavoriteRepository {
    private FavoriteDao favoriteDao;
    private LiveData<List<Favorite>> allFavorites;
    LiveData<List<Favorite>> allAssociatedFavorites;

    public FavoriteRepository(Application application) {
        PortalDataBase trackerDataBase = PortalDataBase.getInstance(application);
        favoriteDao = trackerDataBase.favoriteDao();
        allFavorites = favoriteDao.getAllFavorites();

    }

    public void insert(Favorite favorite) {
        new InsertAsyncTask(favoriteDao).execute(favorite);

    }

    public void update(Favorite favorite) {
        new UpdateAsyncTask(favoriteDao).execute(favorite);

    }

    public void delete(Favorite favorite) {
        new DeleteAsyncTask(favoriteDao).execute(favorite);
    }

    public void deleteAllFavorites() {
        new DeleteAllFavoritesAsyncTask(favoriteDao).execute();
    }

    public LiveData<List<Favorite>> getAllFavorites() {
        return allFavorites;
    }

    public LiveData<List<Favorite>> getAllAssociatedFavorites(int projectId) {
        allAssociatedFavorites = favoriteDao.getAllAssociatedFavorites(projectId);
        return allAssociatedFavorites;
    }

    private static class InsertAsyncTask extends AsyncTask<Favorite, Void, Void> {
        private FavoriteDao favoriteDao;

        private InsertAsyncTask(FavoriteDao favoriteDao) {
            this.favoriteDao = favoriteDao;
        }

        @Override
        protected Void doInBackground(Favorite... favorites) {
            favoriteDao.insert(favorites[0]);
            return null;
        }

    }

    private static class UpdateAsyncTask extends AsyncTask<Favorite, Void, Void> {
        private FavoriteDao favoriteDao;

        private UpdateAsyncTask(FavoriteDao favoriteDao) {
            this.favoriteDao = favoriteDao;
        }

        @Override
        protected Void doInBackground(Favorite... favorites) {
            favoriteDao.update(favorites[0]);
            return null;
        }

    }

    private static class DeleteAsyncTask extends AsyncTask<Favorite, Void, Void> {
        private FavoriteDao favoriteDao;

        private DeleteAsyncTask(FavoriteDao favoriteDao) {
            this.favoriteDao = favoriteDao;
        }

        @Override
        protected Void doInBackground(Favorite... favorites) {
            favoriteDao.delete(favorites[0]);
            return null;
        }

    }

    private static class DeleteAllFavoritesAsyncTask extends AsyncTask<Void, Void, Void> {
        private FavoriteDao favoriteDao;

        private DeleteAllFavoritesAsyncTask(FavoriteDao favoriteDao) {
            this.favoriteDao = favoriteDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            favoriteDao.deleteAllFavorites();
            return null;
        }

    }
}
