package edu.bu.metcs.portal;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import edu.bu.metcs.portal.R;

public class NoteActivity extends AppCompatActivity {
    public static final String EXTRA_NOTE_ID = "edu.bu.metcs.portal.EXTRA_NOTE_ID";
    public static final String EXTRA_PROJECT_ID = "edu.bu.metcs.portal.EXTRA_PROJECT_ID";
    public static final String EXTRA_NOTE_TITLE = "edu.bu.metcs.portal.EXTRA_NOTE_TITLE";
    public static final String EXTRA_NOTE = "edu.bu.metcs.portal.EXTRA_NAME";


    private EditText editTextNoteTitle;
    private EditText editTextNote;
    private EditText editTextCourseFid;
    private NoteViewModel noteViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);

        editTextCourseFid = findViewById(R.id.note_coursefid);
        editTextCourseFid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NoteActivity.this, ProjectUI.class);
                intent.putExtra(ProjectUI.EXTRA_ADD_NOTE, "YES");
                startActivityForResult(intent, 1);
            }
        });
        editTextNoteTitle = findViewById(R.id.note_title);
        editTextNote = findViewById(R.id.note_content);
        Button shareBtn = findViewById(R.id.share_btn);
        shareBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emailNotes();
            }
        });
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close);

        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_NOTE_ID)) {
            setTitle("Edit Note");
            editTextCourseFid.setText(intent.getStringExtra(EXTRA_PROJECT_ID));
            editTextNoteTitle.setText(intent.getStringExtra(EXTRA_NOTE_TITLE));
            editTextNote.setText(intent.getStringExtra(EXTRA_NOTE));

        } else if (intent.hasExtra(EXTRA_PROJECT_ID) && !intent.hasExtra(EXTRA_NOTE_ID)) {
            setTitle("Add Note");
            editTextCourseFid.setText(intent.getStringExtra(EXTRA_PROJECT_ID));
            editTextNoteTitle.setText(intent.getStringExtra(EXTRA_NOTE_TITLE));
            editTextNote.setText(intent.getStringExtra(EXTRA_NOTE));
        }


    }

    private void emailNotes() {
        String noteContents = editTextNote.getText().toString();
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_TEXT, noteContents);
        intent.setType("message/rfc822");
        startActivity(Intent.createChooser(intent, "Choose email client"));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.note_menu, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.save_note:
                saveNote();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    private void saveNote() {
        Intent data = new Intent();
        noteViewModel = ViewModelProviders.of(this).get(NoteViewModel.class);

        String coursefid = editTextCourseFid.getText().toString();
        String noteTitle = editTextNoteTitle.getText().toString();
        String contents = editTextNote.getText().toString();

        if (contents.trim().isEmpty() || coursefid.trim().isEmpty() || noteTitle.trim().isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT);
            return;
        }
        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_PROJECT_ID) && !intent.hasExtra(EXTRA_NOTE_ID)) {
            int courseFid = Integer.valueOf(coursefid);
            Note note = new Note(courseFid, noteTitle, contents);
            noteViewModel.insert(note);
            Toast.makeText(this, "Note has been added successfully", Toast.LENGTH_SHORT).show();
            intent = new Intent(NoteActivity.this, NoteUI.class);
            startActivity(intent);

        } else if (intent.hasExtra(EXTRA_NOTE_ID)) {

            data.putExtra(EXTRA_PROJECT_ID, coursefid);
            data.putExtra(EXTRA_NOTE_TITLE, noteTitle);
            data.putExtra(EXTRA_NOTE, contents);

            int noteId = Integer.valueOf(getIntent().getStringExtra(EXTRA_NOTE_ID));
            if (noteId != -1) {
                data.putExtra(EXTRA_NOTE_ID, noteId);
            }
            setResult(RESULT_OK, data);
            finish();
        }
    }
}
