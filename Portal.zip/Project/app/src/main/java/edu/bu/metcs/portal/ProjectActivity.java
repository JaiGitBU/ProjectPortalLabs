package edu.bu.metcs.portal;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import java.util.List;

import edu.bu.metcs.portal.R.id;

public class ProjectActivity extends AppCompatActivity {
    private static final int EDIT_ASSOC_FAVORITE_REQUEST = 2;
    private static final int EDIT_ASSOC_NOTE_REQUEST = 3;


    public static int projectId;
    public static int numOfAssociatedFavorites = 0;
    private FavoriteView favoriteView;
    private RecyclerView associatedFavorites;

    private NoteViewModel noteViewModel;
    private RecyclerView associatedNotes;


    public static final String EXTRA_PROJECT_ID = "edu.bu.metcs.portal.EXTRA_PROJECT_ID";
    public static final String EXTRA_PORTAL_ID = "edu.bu.metcs.portal.EXTRA_PORTAL_ID";
    public static final String EXTRA_PROJECT_TITLE = "edu.bu.metcs.portal.EXTRA_PROJECT_TITLE";
    public static final String EXTRA_PROJECT_DESCRIPTION = "edu.bu.metcs.portal.EXTRA_PROJECT_DESCRIPTION";
    public static final String EXTRA_ISFAVORITE = "edu.bu.metcs.portal.EXTRA_ISFAVORITE";
    public static final String EXTRA_KEYWORDS = "edu.bu.metcs.portal.EXTRA_KEYWORDS";
    public static final String EXTRA_AUTHORS = "edu.bu.metcs.portal.EXTRA_AUTHORS";

    public static final String EXTRA_LINKS = "edu.bu.metcs.portal.EXTRA_LINKS";

    private EditText editTextPortalId;
    private EditText editTextTitle;
    private EditText editTextDescription;
    private Switch editTextIsFavoriteBtn;
    private EditText editTextKeyword;
    private EditText editTextAuthor;
    private EditText editTextLink;
    private ProjectView projectView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project);

        editTextPortalId = findViewById(R.id.assoc_portal_id);
        editTextPortalId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProjectActivity.this, PortalUI.class);
                intent.putExtra(PortalUI.EXTRA_ADD_PROJECT, "Add course");
                startActivityForResult(intent, ProjectUI.ADD_PROJECT_REQUEST);
            }
        });
        editTextTitle = findViewById(R.id.project_title);
        editTextDescription = findViewById(R.id.description);
        editTextIsFavoriteBtn = findViewById(id.ratingLabel);
        editTextIsFavoriteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editTextIsFavoriteBtn.isChecked()){
                    editTextIsFavoriteBtn.setText("Is favorite? : Yes");

                }
                else {
                    editTextIsFavoriteBtn.setText("Is favorite? : No");
                }

            }
        });
        System.out.println(editTextIsFavoriteBtn.getText());
        editTextKeyword = findViewById(R.id.keyword);
        editTextAuthor = findViewById(R.id.author);
        editTextLink = findViewById(R.id.link);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close);


        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_PROJECT_ID)) {
            setTitle("Edit Project");
            editTextPortalId.setText(intent.getStringExtra(EXTRA_PORTAL_ID));
            editTextTitle.setText(intent.getStringExtra(EXTRA_PROJECT_TITLE));
            editTextDescription.setText(intent.getStringExtra(EXTRA_PROJECT_DESCRIPTION));
            editTextIsFavoriteBtn.setText(intent.getStringExtra(EXTRA_ISFAVORITE));
            editTextKeyword.setText(intent.getStringExtra(EXTRA_KEYWORDS));
            editTextAuthor.setText(intent.getStringExtra(EXTRA_AUTHORS));
            editTextLink.setText(intent.getStringExtra(EXTRA_LINKS));

            /*Associated favorites starts*/
            associatedFavorites = findViewById(R.id.associated_favorites_recylerview);
            associatedFavorites.setLayoutManager(new LinearLayoutManager(this));
            associatedFavorites.setHasFixedSize(true);
            final FavoriteAdapter favoriteAdapter = new FavoriteAdapter();
            associatedFavorites.setAdapter(favoriteAdapter);
            favoriteView = ViewModelProviders.of(this).get(FavoriteView.class);
            projectId = Integer.parseInt(intent.getStringExtra(EXTRA_PROJECT_ID));
            favoriteView.getAllAssociatedFavorites(projectId).observe(this, new Observer<List<Favorite>>() {
                @Override
                public void onChanged(@Nullable List<Favorite> favorites) {
                    favoriteAdapter.submitList(favorites);
                }
            });


            new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
                @Override
                public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                    return false;
                }

                @Override
                public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                    favoriteView.delete(favoriteAdapter.getFavoriteAt(viewHolder.getAdapterPosition()));
                }
            }).attachToRecyclerView(associatedFavorites);


            favoriteAdapter.setOnItemClickedListner(new FavoriteAdapter.OnItemClickedListner() {
                @Override
                public void onItemClicked(Favorite favorite) {
                    Intent intent = new Intent(ProjectActivity.this, FavoriteActivity.class);

                    intent.putExtra(FavoriteActivity.EXTRA_PROJECT_ID, String.valueOf(favorite.getProjectId()));
                    intent.putExtra(FavoriteActivity.EXTRA_FAVORITE_ID, String.valueOf(favorite.getFavoriteId()));
                    intent.putExtra(FavoriteActivity.EXTRA_FAVORITE_TITLE, favorite.getFavoriteTitle());
                    startActivityForResult(intent, EDIT_ASSOC_FAVORITE_REQUEST);
                }
            });

            /*Associated favorite ends*/

            /*Associated note starts*/
            associatedNotes = findViewById(R.id.associated_notes_recylerview);
            associatedNotes.setLayoutManager(new LinearLayoutManager(this));
            associatedNotes.setHasFixedSize(true);
            final NoteAdapter noteAdapter = new NoteAdapter();
            associatedNotes.setAdapter(noteAdapter);
            noteViewModel = ViewModelProviders.of(this).get(NoteViewModel.class);
            projectId = Integer.parseInt(intent.getStringExtra(EXTRA_PROJECT_ID));
            noteViewModel.getAllAssociatedNotes(projectId).observe(this, new Observer<List<Note>>() {
                @Override
                public void onChanged(@Nullable List<Note> notes) {
                    noteAdapter.submitList(notes);
                }
            });


            new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
                @Override
                public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                    return false;
                }

                @Override
                public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                    noteViewModel.delete(noteAdapter.getNoteAt(viewHolder.getAdapterPosition()));
                }
            }).attachToRecyclerView(associatedNotes);


            noteAdapter.setOnItemClickedListner(new NoteAdapter.OnItemClickedListner() {
                @Override
                public void onItemClicked(Note note) {
                    Intent intent = new Intent(ProjectActivity.this, NoteActivity.class);
                    intent.putExtra(NoteActivity.EXTRA_PROJECT_ID, String.valueOf(note.getProjectId()));
                    intent.putExtra(NoteActivity.EXTRA_NOTE_TITLE, note.getNoteTitle());
                    intent.putExtra(NoteActivity.EXTRA_NOTE_ID, String.valueOf(note.getNoteId()));
                    intent.putExtra(NoteActivity.EXTRA_NOTE, note.getNote());
                    startActivityForResult(intent, EDIT_ASSOC_NOTE_REQUEST);
                }
            });

            /*Associated note ends*/


        } else if (intent.hasExtra(EXTRA_PORTAL_ID) && !intent.hasExtra(EXTRA_PROJECT_ID)) {
            setTitle("Add Project");
            editTextPortalId.setText(intent.getStringExtra(EXTRA_PORTAL_ID));
            editTextTitle.setText(intent.getStringExtra(EXTRA_PROJECT_TITLE));
            editTextDescription.setText(editTextDescription.getText());
            editTextIsFavoriteBtn.setText(editTextIsFavoriteBtn.getText());
            editTextKeyword.setText(intent.getStringExtra(EXTRA_KEYWORDS));
            editTextAuthor.setText(intent.getStringExtra(EXTRA_AUTHORS));

            editTextLink.setText(intent.getStringExtra(EXTRA_LINKS));

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.project_menu, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.save_project:
                saveCourse();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    private void saveCourse() {
        Intent data = new Intent();
        projectView = ViewModelProviders.of(this).get(ProjectView.class);


        String strPortalId = editTextPortalId.getText().toString();
        int portalId = Integer.valueOf(strPortalId);
        String title = editTextTitle.getText().toString();
        String description = editTextDescription.getText().toString();
        String isFavorite = editTextIsFavoriteBtn.getText().toString();
        String keyword = editTextKeyword.getText().toString();
        String author = editTextAuthor.getText().toString();
        String link = editTextLink.getText().toString();


        if (String.valueOf(portalId).trim().isEmpty() || title.trim().isEmpty() || description.trim().isEmpty() || isFavorite.trim().isEmpty()
                || keyword.trim().isEmpty() || link.trim().isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT);
            return;
        }

        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_PORTAL_ID) && !(intent.hasExtra(EXTRA_PROJECT_ID))) {

            Project project = new Project(portalId, title, description, isFavorite, keyword, author, link);
            projectView.insert(project);


            Toast.makeText(this, "Project added successfully", Toast.LENGTH_SHORT).show();
            intent = new Intent(ProjectActivity.this, ProjectUI.class);
            startActivity(intent);
        } else if (intent.hasExtra(EXTRA_PROJECT_ID)) {

            data.putExtra(EXTRA_PORTAL_ID, strPortalId);
            data.putExtra(EXTRA_PROJECT_TITLE, title);
            data.putExtra(EXTRA_PROJECT_DESCRIPTION, description);
            data.putExtra(EXTRA_ISFAVORITE, isFavorite);
            data.putExtra(EXTRA_KEYWORDS, keyword);
            data.putExtra(EXTRA_AUTHORS, author);
            data.putExtra(EXTRA_LINKS, link);

            int id = Integer.valueOf(getIntent().getStringExtra(EXTRA_PROJECT_ID));
            if (id != -1) {
                data.putExtra(EXTRA_PROJECT_ID, id);

            }
            setResult(RESULT_OK, data);
            finish();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == EDIT_ASSOC_FAVORITE_REQUEST && resultCode == RESULT_OK) {
            int id = data.getIntExtra(FavoriteActivity.EXTRA_FAVORITE_ID, -1);
            if (id == -1) {
                Toast.makeText(this, "Favorite wasn't updated", Toast.LENGTH_SHORT).show();
                return;
            } else if (data.hasExtra(FavoriteActivity.EXTRA_FAVORITE_ID)) {
                int projectId = Integer.valueOf(data.getStringExtra(FavoriteActivity.EXTRA_PROJECT_ID));
                String title = data.getStringExtra(FavoriteActivity.EXTRA_FAVORITE_TITLE);
                if (numOfAssociatedFavorites < 5) {
                    Favorite favorite = new Favorite(projectId, title);
                    favorite.setFavoriteId(id);
                    favoriteView.update(favorite);
                    Toast.makeText(this, "Favorite updated", Toast.LENGTH_SHORT).show();
                }

            } else {
                Toast.makeText(this, "Favorite was not saved", Toast.LENGTH_SHORT).show();
            }

        } else if (requestCode == EDIT_ASSOC_NOTE_REQUEST && resultCode == RESULT_OK) {
            int id = data.getIntExtra(NoteActivity.EXTRA_NOTE_ID, -1);
            if (id == -1) {
                Toast.makeText(this, "Note can't be updated", Toast.LENGTH_SHORT).show();
                return;
            } else if (data.hasExtra(NoteActivity.EXTRA_NOTE_ID)) {

                int courseFid = Integer.valueOf(data.getStringExtra(NoteActivity.EXTRA_PROJECT_ID));
                String text = data.getStringExtra(NoteActivity.EXTRA_NOTE);
                String noteTitle = data.getStringExtra(NoteActivity.EXTRA_NOTE_TITLE);
                Note note = new Note(courseFid, noteTitle, text);
                note.setNoteId(id);
                noteViewModel.update(note);
                Toast.makeText(this, "Note updated", Toast.LENGTH_SHORT).show();
            } else {

                Toast.makeText(this, "Note wasn't saved", Toast.LENGTH_SHORT).show();
            }


        }
    }
}


