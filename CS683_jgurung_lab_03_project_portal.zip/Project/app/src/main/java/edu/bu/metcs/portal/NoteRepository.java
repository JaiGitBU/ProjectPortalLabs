package edu.bu.metcs.portal;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import java.util.List;

public class NoteRepository {
    private NoteDao noteDao;
    private LiveData<List<Note>> allNotes;
    private LiveData<List<Note>> allAssociatedNotes;

    public NoteRepository(Application application) {
        PortalDataBase trackerDataBase = PortalDataBase.getInstance(application);
        noteDao = trackerDataBase.noteDao();
        allNotes = noteDao.getAllNotes();

    }

    public void insert(Note course) {
        new InsertAsyncTask(noteDao).execute(course);

    }

    public void update(Note course) {
        new UpdateAsyncTask(noteDao).execute(course);

    }

    public void delete(Note course) {
        new DeleteAsyncTask(noteDao).execute(course);
    }

    public void deleteAllNotes() {
        new DeleteAllNotesAsyncTask(noteDao).execute();
    }

    public LiveData<List<Note>> getAllNotes() {
        return allNotes;
    }

    public LiveData<List<Note>> getAllAssociatedNotes(int courseId) {
        allAssociatedNotes = noteDao.getAllAssociatedNotes(courseId);
        return allAssociatedNotes;
    }

    private static class InsertAsyncTask extends AsyncTask<Note, Void, Void> {
        private NoteDao noteDao;

        private InsertAsyncTask(NoteDao noteDao) {
            this.noteDao = noteDao;
        }

        @Override
        protected Void doInBackground(Note... courses) {
            noteDao.insert(courses[0]);
            return null;
        }

    }

    private static class UpdateAsyncTask extends AsyncTask<Note, Void, Void> {
        private NoteDao noteDao;

        private UpdateAsyncTask(NoteDao noteDao) {
            this.noteDao = noteDao;
        }

        @Override
        protected Void doInBackground(Note... courses) {
            noteDao.update(courses[0]);
            return null;
        }

    }

    private static class DeleteAsyncTask extends AsyncTask<Note, Void, Void> {
        private NoteDao noteDao;

        private DeleteAsyncTask(NoteDao noteDao) {
            this.noteDao = noteDao;
        }

        @Override
        protected Void doInBackground(Note... courses) {
            noteDao.delete(courses[0]);
            return null;
        }

    }

    private static class DeleteAllNotesAsyncTask extends AsyncTask<Void, Void, Void> {
        private NoteDao noteDao;

        private DeleteAllNotesAsyncTask(NoteDao noteDao) {
            this.noteDao = noteDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            noteDao.deleteAllNotes();
            return null;
        }

    }
}
