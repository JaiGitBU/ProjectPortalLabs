package edu.bu.metcs.portal;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.RoomWarnings;
import android.arch.persistence.room.Update;

import java.util.List;

@Dao
public interface FavoriteDao {

    @Insert
    void insert(Favorite favorite);

    @Update
    void update(Favorite favorite);

    @Delete
    void delete(Favorite favorite);

    @Query("DELETE FROM Favorites")
    void deleteAllFavorites();

    @Query("SELECT * FROM Favorites")
    LiveData<List<Favorite>> getAllFavorites();

    @Query("SELECT * FROM Favorites WHERE projectId = :projectId")
    @SuppressWarnings(RoomWarnings.CURSOR_MISMATCH)
    LiveData<List<Favorite>> getAllAssociatedFavorites(int projectId);

}
