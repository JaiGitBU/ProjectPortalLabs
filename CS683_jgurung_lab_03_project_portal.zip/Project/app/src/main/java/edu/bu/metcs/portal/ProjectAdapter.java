package edu.bu.metcs.portal;

import android.support.annotation.NonNull;
import android.support.v7.recyclerview.extensions.ListAdapter;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import edu.bu.metcs.portal.R;

public class ProjectAdapter extends ListAdapter<Project, ProjectAdapter.CourseHolder> {


    private OnItemClickedListner listner;

    public ProjectAdapter() {
        super(DIFF_CALLBACK);

    }

    private static final DiffUtil.ItemCallback<Project> DIFF_CALLBACK = new DiffUtil.ItemCallback<Project>() {
        @Override
        public boolean areItemsTheSame(@NonNull Project oldProject, @NonNull Project newProject) {
            return oldProject.getProjectId() == newProject.getProjectId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Project oldProject, @NonNull Project newProject) {
            return oldProject.getPortalId() == (newProject.getPortalId())
                    && oldProject.getProjectTitle().equals(newProject.getProjectTitle())
                    && oldProject.getProjectDescription().equals(newProject.getProjectDescription())
                    && oldProject.getIsFavorite().equals(newProject.getIsFavorite())
                    && oldProject.getKeywords().equals(newProject.getKeywords())
                    && oldProject.getAuthors().equals(newProject.getAuthors())
                    && oldProject.getLink().equals(newProject.getLink());
        }
    };

    @NonNull
    @Override
    public ProjectAdapter.CourseHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.project_item, parent, false);
        return new CourseHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProjectAdapter.CourseHolder holder, int position) {
        Project curProject = getItem(position);
        holder.textViewTermId.setText(String.valueOf(curProject.getPortalId()));
        holder.textViewTitle.setText(curProject.getProjectTitle());
        holder.textViewStart.setText(curProject.getProjectDescription());
        holder.textViewEnd.setText(curProject.getIsFavorite());
        holder.textViewStatus.setText(curProject.getKeywords());
        holder.textViewMentor.setText(curProject.getAuthors());
        holder.textViewEmail.setText(curProject.getLink());
    }

    public Project getProjectAt(int position) {
        return getItem(position);
    }

    class CourseHolder extends RecyclerView.ViewHolder {
        private TextView textViewTermId;
        private TextView textViewTitle;
        private TextView textViewStart;
        private TextView textViewEnd;
        private TextView textViewStatus;
        private TextView textViewMentor;
        private TextView textViewEmail;

        public CourseHolder(View itemView) {
            super(itemView);
            textViewTermId = itemView.findViewById(R.id.associated_portal_id);
            textViewTitle = itemView.findViewById(R.id.project_title);
            textViewStart = itemView.findViewById(R.id.description);
            textViewEnd = itemView.findViewById(R.id.favorite);
            textViewStatus = itemView.findViewById(R.id.keyword);
            textViewMentor = itemView.findViewById(R.id.author);
            textViewEmail = itemView.findViewById(R.id.link);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (listner != null && position != RecyclerView.NO_POSITION) {
                        listner.onItemClicked(getItem(position));
                    }
                }
            });


        }
    }

    public interface OnItemClickedListner {
        void onItemClicked(Project project);

    }

    public void setOnItemClickedListner(OnItemClickedListner listner) {
        this.listner = listner;
    }
}
