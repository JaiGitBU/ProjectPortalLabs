package edu.bu.metcs.portal;

import android.app.DatePickerDialog;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

import edu.bu.metcs.portal.R;

import static edu.bu.metcs.portal.FavoriteUI.ADD_FAVORITE_REQUEST;

public class FavoriteActivity extends AppCompatActivity {
    public static final String EXTRA_FAVORITE_ID = "edu.bu.metcs.portal.EXTRA_FAVORITE_ID";
    public static final String EXTRA_PROJECT_ID = "edu.bu.metcs.portal.EXTRA_PROJECT_ID";
    public static final String EXTRA_FAVORITE_TITLE = "edu.bu.metcs.portal.EXTRA_FAVORITE_TITLE";


    private EditText editTextProjectId;
    private EditText editTextTitle;
    private FavoriteView favoriteView;
    private DatePickerDialog.OnDateSetListener onDateSetListener;
    private int numOfAssociatedFavorites;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        editTextProjectId = findViewById(R.id.assoc_project_id);
        editTextProjectId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FavoriteActivity.this, ProjectUI.class);
                intent.putExtra(ProjectUI.EXTRA_ADD_FAVORITE, "Add Favorite");
                startActivityForResult(intent, ADD_FAVORITE_REQUEST);

            }
        });

        editTextTitle = findViewById(R.id.favorite_title);



        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close);

        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_FAVORITE_ID)) {
            setTitle("Edit Favorite");
            editTextProjectId.setText(intent.getStringExtra(EXTRA_PROJECT_ID));
            editTextTitle.setText(intent.getStringExtra(EXTRA_FAVORITE_TITLE));


        } else if (intent.hasExtra(EXTRA_PROJECT_ID) && !intent.hasExtra(EXTRA_FAVORITE_ID)) {
            setTitle("Add Favorite");
            editTextProjectId.setText(intent.getStringExtra(EXTRA_PROJECT_ID));
            editTextTitle.setText(intent.getStringExtra(EXTRA_FAVORITE_TITLE));

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.favorite_menu, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.save_favorite:
                saveAssesment();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    private void saveAssesment() {
        Intent data = new Intent();
        favoriteView = ViewModelProviders.of(this).get(FavoriteView.class);
        String strProjectId = editTextProjectId.getText().toString();
        String title = editTextTitle.getText().toString();


        if (title.trim().isEmpty()) {
            Toast.makeText(this, "Title is missing", Toast.LENGTH_SHORT);
            return;
        }
        /*Add assesment*/
        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_PROJECT_ID) && !intent.hasExtra(EXTRA_FAVORITE_ID)) {

            int projectId = Integer.parseInt(strProjectId);
            favoriteView = ViewModelProviders.of(FavoriteActivity.this).get(FavoriteView.class);
            favoriteView.getAllAssociatedFavorites(projectId).observe(this, new Observer<List<Favorite>>() {
                @Override
                public void onChanged(@Nullable List<Favorite> favorites) {

                    numOfAssociatedFavorites = favorites.size();
                }
            });
            if (numOfAssociatedFavorites < 5) {
                Favorite favorite = new Favorite(projectId, title);
                favoriteView.insert(favorite);

                Toast.makeText(this, "Favorite saved successfully", Toast.LENGTH_SHORT).show();
            }
            intent = new Intent(FavoriteActivity.this, FavoriteUI.class);
            startActivity(intent);
            /*Send new data to UI for edit*/
        } else if (intent.hasExtra(EXTRA_FAVORITE_ID)) {
            data.putExtra(EXTRA_PROJECT_ID, strProjectId);
            data.putExtra(EXTRA_FAVORITE_TITLE, title);


            int id = Integer.valueOf(getIntent().getStringExtra(EXTRA_FAVORITE_ID));
            if (id != -1) {
                data.putExtra(EXTRA_FAVORITE_ID, id);
            }
            setResult(RESULT_OK, data);
            finish();
        }
    }
}
