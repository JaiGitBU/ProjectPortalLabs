package edu.bu.metcs.portal;

import android.support.annotation.NonNull;
import android.support.v7.recyclerview.extensions.ListAdapter;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class FavoriteAdapter extends ListAdapter<Favorite, FavoriteAdapter.FavoriteHolder> {


    private OnItemClickedListner listner;

    public FavoriteAdapter() {
        super(DIFF_CALLBACK);

    }

    private static final DiffUtil.ItemCallback<Favorite> DIFF_CALLBACK = new DiffUtil.ItemCallback<Favorite>() {
        @Override
        public boolean areItemsTheSame(@NonNull Favorite oldFavorite, @NonNull Favorite newFavorite) {
            return oldFavorite.getFavoriteId() == newFavorite.getFavoriteId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Favorite oldFavorite, @NonNull Favorite newFavorite) {
            return oldFavorite.getFavoriteTitle().equals(newFavorite.getFavoriteTitle())
                    && oldFavorite.getProjectId() == (newFavorite.getProjectId());
        }
    };

    @NonNull
    @Override
    public FavoriteAdapter.FavoriteHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.favorite_item, parent, false);
        return new FavoriteHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull FavoriteAdapter.FavoriteHolder holder, int position) {
        Favorite curFavorite = getItem(position);
        holder.textViewProjectId.setText(String.valueOf(curFavorite.getProjectId()));
        holder.textViewTitle.setText(curFavorite.getFavoriteTitle());


    }

    public Favorite getFavoriteAt(int position) {
        return getItem(position);
    }

    class FavoriteHolder extends RecyclerView.ViewHolder {
        private TextView textViewProjectId;
        private TextView textViewTitle;

        public FavoriteHolder(View itemView) {
            super(itemView);
            textViewProjectId = itemView.findViewById(R.id.associated_project_id);
            textViewTitle = itemView.findViewById(R.id.favorite_title);



            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (listner != null && position != RecyclerView.NO_POSITION) {
                        listner.onItemClicked(getItem(position));
                    }
                }
            });


        }
    }

    public interface OnItemClickedListner {
        void onItemClicked(Favorite favorite);

    }

    public void setOnItemClickedListner(OnItemClickedListner listner) {
        this.listner = listner;
    }
}
