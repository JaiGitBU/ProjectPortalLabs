package edu.bu.metcs.portal;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import java.util.List;

public class ProjectRepository {

    private ProjectDao projectDao;
    private LiveData<List<Project>> allProjects;
    private LiveData<List<Project>> allAssociatedProjects;


    public ProjectRepository(Application application) {
        PortalDataBase portalDataBase = PortalDataBase.getInstance(application);
        projectDao = portalDataBase.projectDao();
        allProjects = projectDao.getAllProjects();


    }

    public void insert(Project project) {
        new InsertAsyncTask(projectDao).execute(project);

    }

    public void update(Project project) {
        new UpdateAsyncTask(projectDao).execute(project);

    }

    public void delete(Project project) {
        new DeleteAsyncTask(projectDao).execute(project);
    }

    public void deleteAllProjects() {
        new DeleteAllCoursesAsyncTask(projectDao).execute();
    }

    public LiveData<List<Project>> getAllProjects() {
        return allProjects;
    }

    public LiveData<List<Project>> getAllAssociatedProjects(int portalId) {
        allAssociatedProjects = projectDao.getAllAssociatedProjects(portalId);
        return allAssociatedProjects;
    }


    private static class InsertAsyncTask extends AsyncTask<Project, Void, Void> {
        private ProjectDao projectDao;

        private InsertAsyncTask(ProjectDao projectDao) {
            this.projectDao = projectDao;
        }

        @Override
        protected Void doInBackground(Project... cours) {
            projectDao.insert(cours[0]);
            return null;
        }

    }

    private static class UpdateAsyncTask extends AsyncTask<Project, Void, Void> {
        private ProjectDao projectDao;

        private UpdateAsyncTask(ProjectDao projectDao) {
            this.projectDao = projectDao;
        }

        @Override
        protected Void doInBackground(Project... cours) {
            projectDao.update(cours[0]);
            return null;
        }

    }

    private static class DeleteAsyncTask extends AsyncTask<Project, Void, Void> {
        private ProjectDao projectDao;

        private DeleteAsyncTask(ProjectDao projectDao) {
            this.projectDao = projectDao;
        }

        @Override
        protected Void doInBackground(Project... cours) {
            projectDao.delete(cours[0]);
            return null;
        }

    }

    private static class DeleteAllCoursesAsyncTask extends AsyncTask<Void, Void, Void> {
        private ProjectDao projectDao;

        private DeleteAllCoursesAsyncTask(ProjectDao projectDao) {
            this.projectDao = projectDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            projectDao.deleteAllProjects();
            return null;
        }

    }

    private static class GetAllAssociatedProjectAsyncTask extends AsyncTask<Integer, Void, Void> {
        private ProjectDao projectDao;

        private GetAllAssociatedProjectAsyncTask(ProjectDao projectDao) {
            this.projectDao = projectDao;
        }

        @Override
        protected Void doInBackground(Integer... integers) {
            return null;
        }
    }
}
