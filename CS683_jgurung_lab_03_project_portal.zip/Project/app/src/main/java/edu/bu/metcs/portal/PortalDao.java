package edu.bu.metcs.portal;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.RoomWarnings;
import android.arch.persistence.room.Update;

import java.util.List;

@Dao
public interface PortalDao {
    @Insert
    void insert(Portal portal);

    @Update
    void update(Portal portal);

    @Delete
    void delete(Portal portal);

    @Query("DELETE FROM Portals")
    void deleteAllTerms();

    @Query("SELECT * FROM Portals ORDER BY id")
    LiveData<List<Portal>> getAllTerms();

    @Query("SELECT * FROM Projects WHERE portalId = :id")
    @SuppressWarnings(RoomWarnings.CURSOR_MISMATCH)
    LiveData<List<Project>> getAllAssociatedCourses(int id);

}
