package edu.bu.metcs.portal;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import java.util.List;

public class PortalView extends AndroidViewModel {
    private PortalRepository repository;
    private LiveData<List<Portal>> allTerms;


    public PortalView(@NonNull Application application) {
        super(application);
        repository = new PortalRepository(application);
        allTerms = repository.getAllPortals();

    }

    public void insert(Portal portal) {
        repository.insert(portal);
    }

    public void update(Portal portal) {
        repository.update(portal);
    }

    public void delete(Portal portal) {
        repository.delete(portal);
    }

    public void deleteAllTerms() {
        repository.deleteAllPortals();
    }

    public LiveData<List<Portal>> getAllTerms() {
        return allTerms;
    }


}
