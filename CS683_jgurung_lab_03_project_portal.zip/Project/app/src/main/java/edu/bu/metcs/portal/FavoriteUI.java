package edu.bu.metcs.portal;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.util.List;

import edu.bu.metcs.portal.R;

public class FavoriteUI extends AppCompatActivity {
    public static final int ADD_FAVORITE_REQUEST = 1;
    public static final int EDIT_FAVORITES_REQUEST = 2;
    private FavoriteView favoriteView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.favorite_ui);

        /*Add favorites request*/
        FloatingActionButton buttonAddAssesment = findViewById(R.id.add_favorite);
        buttonAddAssesment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FavoriteUI.this, FavoriteActivity.class);
                startActivityForResult(intent, ADD_FAVORITE_REQUEST);
            }
        });
        /*Create recyler view with favorites list*/
        RecyclerView recyclerView = findViewById(R.id.favorite_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        final FavoriteAdapter adapter = new FavoriteAdapter();
        recyclerView.setAdapter(adapter);

        favoriteView = ViewModelProviders.of(this).get(FavoriteView.class);
        favoriteView.getAllFavorites().observe(this, new Observer<List<Favorite>>() {

            /*Slide assesment L/R to delete*/
            @Override
            public void onChanged(@Nullable List<Favorite> favorites) {


                adapter.submitList(favorites);
            }
        });


        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                favoriteView.delete(adapter.getFavoriteAt(viewHolder.getAdapterPosition()));
            }
        }).attachToRecyclerView(recyclerView);

        /*Click on favorite for favorites edit request*/

        adapter.setOnItemClickedListner(new FavoriteAdapter.OnItemClickedListner() {
            @Override
            public void onItemClicked(Favorite favorite) {
                Intent intent = new Intent(FavoriteUI.this, FavoriteActivity.class);

                intent.putExtra(FavoriteActivity.EXTRA_FAVORITE_ID, String.valueOf(favorite.getFavoriteId()));
                intent.putExtra(FavoriteActivity.EXTRA_PROJECT_ID, String.valueOf(favorite.getProjectId()));
                intent.putExtra(FavoriteActivity.EXTRA_FAVORITE_TITLE, favorite.getFavoriteTitle());
                startActivityForResult(intent, EDIT_FAVORITES_REQUEST);


            }
        });

    }

    /*Getting favorites edit request data to update*/

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == EDIT_FAVORITES_REQUEST && resultCode == RESULT_OK) {
            int id = data.getIntExtra(FavoriteActivity.EXTRA_FAVORITE_ID, -1);
            if (id == -1) {
                Toast.makeText(this, "Favorite can't be updated", Toast.LENGTH_SHORT).show();
                return;
            } else {
                int courseId = Integer.valueOf(data.getStringExtra(FavoriteActivity.EXTRA_PROJECT_ID));
                String title = data.getStringExtra(FavoriteActivity.EXTRA_FAVORITE_TITLE);

                Favorite favorite = new Favorite(courseId, title);
                favorite.setFavoriteId(id);
                favoriteView.update(favorite);
                Toast.makeText(this, "Favorite updated", Toast.LENGTH_SHORT).show();
            }

        } else {

            Toast.makeText(this, "Favorite not saved", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.favorite_ui_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.delete_all_favorites:
                favoriteView.deleteAllFavorites();
                Toast.makeText(this, "All Favorites deleted", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }


}
