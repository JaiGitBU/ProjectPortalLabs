package edu.bu.metcs.portal;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import java.util.List;

import edu.bu.metcs.portal.R.id;

public class ProjectActivity extends AppCompatActivity {
    public static int projectId;
    public static final String EXTRA_PROJECT_ID = "edu.bu.metcs.portal.EXTRA_PROJECT_ID";
    public static final String EXTRA_PORTAL_ID = "edu.bu.metcs.portal.EXTRA_PORTAL_ID";
    public static final String EXTRA_PROJECT_TITLE = "edu.bu.metcs.portal.EXTRA_PROJECT_TITLE";
    public static final String EXTRA_PROJECT_DESCRIPTION = "edu.bu.metcs.portal.EXTRA_PROJECT_DESCRIPTION";
    public static final String EXTRA_ISFAVORITE = "edu.bu.metcs.portal.EXTRA_ISFAVORITE";
    public static final String EXTRA_KEYWORDS = "edu.bu.metcs.portal.EXTRA_KEYWORDS";
    public static final String EXTRA_AUTHORS = "edu.bu.metcs.portal.EXTRA_AUTHORS";

    public static final String EXTRA_LINKS = "edu.bu.metcs.portal.EXTRA_LINKS";

    private EditText editTextPortalId;
    private EditText editTextTitle;
    private EditText editTextDescription;
    private Switch editTextIsFavoriteBtn;
    private EditText editTextKeyword;
    private EditText editTextAuthor;
    private EditText editTextLink;
    private ProjectView projectView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project);

        editTextPortalId = findViewById(R.id.assoc_portal_id);
        editTextPortalId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProjectActivity.this, PortalUI.class);
                intent.putExtra(PortalUI.EXTRA_ADD_PROJECT, "Add course");
                startActivityForResult(intent, ProjectUI.ADD_PROJECT_REQUEST);
            }
        });
        editTextTitle = findViewById(R.id.project_title);
        editTextDescription = findViewById(R.id.description);
        editTextIsFavoriteBtn = findViewById(id.ratingLabel);
        editTextIsFavoriteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editTextIsFavoriteBtn.isChecked()){
                    editTextIsFavoriteBtn.setText("Is favorite? : Yes");

                }
                else {
                    editTextIsFavoriteBtn.setText("Is favorite? : No");
                }

            }
        });
        System.out.println(editTextIsFavoriteBtn.getText());
        editTextKeyword = findViewById(R.id.keyword);
        editTextAuthor = findViewById(R.id.author);
        editTextLink = findViewById(R.id.link);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close);


        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_PROJECT_ID)) {
            setTitle("Edit Project");
            editTextPortalId.setText(intent.getStringExtra(EXTRA_PORTAL_ID));
            editTextTitle.setText(intent.getStringExtra(EXTRA_PROJECT_TITLE));
            editTextDescription.setText(intent.getStringExtra(EXTRA_PROJECT_DESCRIPTION));
            editTextIsFavoriteBtn.setText(intent.getStringExtra(EXTRA_ISFAVORITE));
            editTextKeyword.setText(intent.getStringExtra(EXTRA_KEYWORDS));
            editTextAuthor.setText(intent.getStringExtra(EXTRA_AUTHORS));
            editTextLink.setText(intent.getStringExtra(EXTRA_LINKS));




        } else if (intent.hasExtra(EXTRA_PORTAL_ID) && !intent.hasExtra(EXTRA_PROJECT_ID)) {
            setTitle("Add Project");
            editTextPortalId.setText(intent.getStringExtra(EXTRA_PORTAL_ID));
            editTextTitle.setText(intent.getStringExtra(EXTRA_PROJECT_TITLE));
            editTextDescription.setText(editTextDescription.getText());
            editTextIsFavoriteBtn.setText(editTextIsFavoriteBtn.getText());
            editTextKeyword.setText(intent.getStringExtra(EXTRA_KEYWORDS));
            editTextAuthor.setText(intent.getStringExtra(EXTRA_AUTHORS));
            editTextLink.setText(intent.getStringExtra(EXTRA_LINKS));

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.project_menu, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.save_project:
                saveCourse();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    private void saveCourse() {
        Intent data = new Intent();
        projectView = ViewModelProviders.of(this).get(ProjectView.class);


        String strPortalId = editTextPortalId.getText().toString();
        int portalId = Integer.valueOf(strPortalId);
        String title = editTextTitle.getText().toString();
        String description = editTextDescription.getText().toString();
        String isFavorite = editTextIsFavoriteBtn.getText().toString();
        String keyword = editTextKeyword.getText().toString();
        String author = editTextAuthor.getText().toString();
        String link = editTextLink.getText().toString();


        if (String.valueOf(portalId).trim().isEmpty() || title.trim().isEmpty() || description.trim().isEmpty() || isFavorite.trim().isEmpty()
                || keyword.trim().isEmpty() || link.trim().isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT);
            return;
        }

        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_PORTAL_ID) && !(intent.hasExtra(EXTRA_PROJECT_ID))) {

            Project project = new Project(portalId, title, description, isFavorite, keyword, author, link);
            projectView.insert(project);


            Toast.makeText(this, "Project added successfully", Toast.LENGTH_SHORT).show();
            intent = new Intent(ProjectActivity.this, ProjectUI.class);
            startActivity(intent);
        } else if (intent.hasExtra(EXTRA_PROJECT_ID)) {

            data.putExtra(EXTRA_PORTAL_ID, strPortalId);
            data.putExtra(EXTRA_PROJECT_TITLE, title);
            data.putExtra(EXTRA_PROJECT_DESCRIPTION, description);
            data.putExtra(EXTRA_ISFAVORITE, isFavorite);
            data.putExtra(EXTRA_KEYWORDS, keyword);
            data.putExtra(EXTRA_AUTHORS, author);
            data.putExtra(EXTRA_LINKS, link);

            int id = Integer.valueOf(getIntent().getStringExtra(EXTRA_PROJECT_ID));
            if (id != -1) {
                data.putExtra(EXTRA_PROJECT_ID, id);

            }
            setResult(RESULT_OK, data);
            finish();
        }

    }
}


