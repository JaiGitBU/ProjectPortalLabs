package edu.bu.metcs.portal;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import java.util.List;

public class ProjectView extends AndroidViewModel {
    private ProjectRepository repository;
    private LiveData<List<Project>> allProjects;
    private LiveData<List<Project>> associatedProjects;
    private LiveData<List<Project>> allFavorites;


    public ProjectView(@NonNull Application application) {
        super(application);
        repository = new ProjectRepository(application);
        allProjects = repository.getAllProjects();

    }

    public void insert(Project project) {
        repository.insert(project);
    }

    public void update(Project project) {
        repository.update(project);
    }

    public void delete(Project project) {
        repository.delete(project);
    }

    public void deleteAllProjects() {
        repository.getAllProjects();
    }

    public LiveData<List<Project>> getAllProjects() {
        return allProjects;
    }


    public LiveData<List<Project>> getAllAssociatedProjects(int termId) {
        associatedProjects = repository.getAllAssociatedProjects(termId);

        return associatedProjects;
    }


    public LiveData<List<Project>> getAllFavorites(String isFavorite) {
        allFavorites = repository.getAllFavorites(isFavorite);
        return allFavorites;
    }
}
