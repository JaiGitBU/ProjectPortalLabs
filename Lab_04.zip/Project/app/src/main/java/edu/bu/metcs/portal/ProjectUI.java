package edu.bu.metcs.portal;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.util.List;

import edu.bu.metcs.portal.R;

public class ProjectUI extends AppCompatActivity {
    public static final int ADD_PROJECT_REQUEST = 1;
    public static final int EDIT_PROJECT_REQUEST = 2;
    public static final String EXTRA_ADD_FAVORITE = "edu.bu.metcs.portal.EXTRA_ADD_FAVORITE";
    public static final String EXTRA_ADD_NOTE = "edu.bu.metcs.portal.EXTRA_ADD_NOTE";
    private ProjectView projectView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.project_ui);

        FloatingActionButton buttonAddCourse = findViewById(R.id.add_project);
        buttonAddCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProjectUI.this, ProjectActivity.class);
                startActivityForResult(intent, ADD_PROJECT_REQUEST);
            }
        });

        RecyclerView recyclerView = findViewById(R.id.project_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        final ProjectAdapter adapter = new ProjectAdapter();
        recyclerView.setAdapter(adapter);

        projectView = ViewModelProviders.of(this).get(ProjectView.class);
        projectView.getAllProjects().observe(this, new Observer<List<Project>>() {
            @Override
            public void onChanged(@Nullable List<Project> projects) {

                adapter.submitList(projects);
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                projectView.delete(adapter.getProjectAt(viewHolder.getAdapterPosition()));
            }
        }).attachToRecyclerView(recyclerView);


        adapter.setOnItemClickedListner(new ProjectAdapter.OnItemClickedListner() {
            @Override
            public void onItemClicked(Project project) {
                Intent intent = getIntent();
                    intent = new Intent(ProjectUI.this, ProjectActivity.class);
                    intent.putExtra(ProjectActivity.EXTRA_PROJECT_ID, String.valueOf(project.getProjectId()));
                    intent.putExtra(ProjectActivity.EXTRA_PORTAL_ID, String.valueOf(project.getPortalId()));
                    intent.putExtra(ProjectActivity.EXTRA_PROJECT_TITLE, project.getProjectTitle());
                    intent.putExtra(ProjectActivity.EXTRA_PROJECT_DESCRIPTION, project.getProjectDescription());
                    intent.putExtra(ProjectActivity.EXTRA_ISFAVORITE, project.getIsFavorite());
                    intent.putExtra(ProjectActivity.EXTRA_KEYWORDS, project.getKeywords());
                    intent.putExtra(ProjectActivity.EXTRA_AUTHORS, project.getAuthors());
                    intent.putExtra(ProjectActivity.EXTRA_LINKS, project.getLink());
                    startActivityForResult(intent, EDIT_PROJECT_REQUEST);


            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_PROJECT_REQUEST && resultCode == RESULT_OK) {
            int termFid = Integer.parseInt(data.getStringExtra(ProjectActivity.EXTRA_PORTAL_ID));
            String title = data.getStringExtra(ProjectActivity.EXTRA_PROJECT_TITLE);
            String description = data.getStringExtra(ProjectActivity.EXTRA_PROJECT_DESCRIPTION);
            String isFavorite = data.getStringExtra(ProjectActivity.EXTRA_ISFAVORITE);
            String keywords = data.getStringExtra(ProjectActivity.EXTRA_KEYWORDS);
            String authors = data.getStringExtra(ProjectActivity.EXTRA_AUTHORS);
            String links = data.getStringExtra(ProjectActivity.EXTRA_LINKS);

            Toast.makeText(this, "Project added successfully", Toast.LENGTH_SHORT).show();
            return;

        } else if (requestCode == EDIT_PROJECT_REQUEST && resultCode == RESULT_OK) {
            int id = data.getIntExtra(ProjectActivity.EXTRA_PROJECT_ID, -1);
            if (id == -1) {
                Toast.makeText(this, "Project can't be updated", Toast.LENGTH_SHORT).show();
                return;
            } else {
                String portalId = data.getStringExtra((ProjectActivity.EXTRA_PORTAL_ID));
                int intTermId = Integer.valueOf(portalId);
                String title = data.getStringExtra(ProjectActivity.EXTRA_PROJECT_TITLE);
                String description = data.getStringExtra(ProjectActivity.EXTRA_PROJECT_DESCRIPTION);
                String isFavorite = data.getStringExtra(ProjectActivity.EXTRA_ISFAVORITE);
                String keywords = data.getStringExtra(ProjectActivity.EXTRA_KEYWORDS);
                String authors = data.getStringExtra(ProjectActivity.EXTRA_AUTHORS);
                String links = data.getStringExtra(ProjectActivity.EXTRA_LINKS);

                Project project = new Project(intTermId, title, description, isFavorite, keywords, authors, links);
                project.setProjectId(id);
                projectView.update(project);
                Toast.makeText(this, "Project updated", Toast.LENGTH_SHORT).show();
            }

        } else {

            Toast.makeText(this, "Project not saved", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.project_ui_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.delete_all_projects:
                projectView.deleteAllProjects();
                Toast.makeText(this, "All Projects deleted", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.select_favorites:

                Toast.makeText(this, "Showing all favorites", Toast.LENGTH_SHORT).show();
                RecyclerView recyclerView = findViewById(R.id.project_recycler_view);
                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                recyclerView.setHasFixedSize(true);

                final ProjectAdapter adapter = new ProjectAdapter();
                recyclerView.setAdapter(adapter);

                projectView = ViewModelProviders.of(this).get(ProjectView.class);
                projectView.getAllFavorites("Is favorite? : Yes").observe(this, new Observer<List<Project>>() {
                    @Override
                    public void onChanged(@Nullable List<Project> projects) {

                        adapter.submitList(projects);
                    }
                });
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
