package edu.bu.metcs.portal;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.util.List;

import edu.bu.metcs.portal.R;

public class PortalUI extends AppCompatActivity {
    public static final String EXTRA_EDIT_PORTAL = "edu.bu.metcs.myproject.EXTRA_EDIT_PORTAL";
    public static final String EXTRA_ADD_PROJECT = "edu.bu.metcs.myproject.EXTRA_ADD_PROJECT";
    public static final int ADD_PORTAL_REQUEST = 1;
    public static final int EDIT_PORTAL_REQUEST = 2;


    private PortalView portalView;
    private ProjectView projectView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.portal_ui);

        FloatingActionButton buttonAddPortal = findViewById(R.id.add_portal);


        buttonAddPortal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(PortalUI.this, PortalActivity.class);
                startActivityForResult(intent, ADD_PORTAL_REQUEST);
            }
        });


        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        final PortalAdapter adapter = new PortalAdapter();
        recyclerView.setAdapter(adapter);

        portalView = ViewModelProviders.of(this).get(PortalView.class);
        portalView.getAllPortals().observe(this, new Observer<List<Portal>>() {
            @Override
            public void onChanged(@Nullable List<Portal> portals) {


                adapter.submitList(portals);
            }
        });


        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            private RecyclerView.ViewHolder viewHolder;

            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull final RecyclerView.ViewHolder viewHolder, int direction) {

                projectView = ViewModelProviders.of(PortalUI.this).get(ProjectView.class);
                projectView.getAllAssociatedProjects(adapter.getPortalAt(viewHolder.getAdapterPosition()).getId()).observe(PortalUI.this, new Observer<List<Project>>() {

                    @Override
                    public void onChanged(@Nullable List<Project> project) {
                        if (project.isEmpty()) {
                            portalView.delete(adapter.getPortalAt(viewHolder.getAdapterPosition()));
                        } else {
                            Toast.makeText(PortalUI.this, "Portal can't be deleted. It has associated project", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(PortalUI.this, PortalUI.class);
                            startActivity(intent);
                        }

                    }
                });

            }


        }).attachToRecyclerView(recyclerView);


        adapter.setOnItemClickedListner(new PortalAdapter.OnItemClickedListner() {
            @Override
            public void onItemClicked(Portal portal) {

                Intent intent = getIntent();
                if (intent.hasExtra(EXTRA_ADD_PROJECT)) {
                    intent = new Intent(PortalUI.this, ProjectActivity.class);
                    intent.putExtra(ProjectActivity.EXTRA_PORTAL_ID, Integer.toString(portal.getId()));
                    startActivity(intent);
                } else {
                    intent = new Intent(PortalUI.this, PortalActivity.class);
                    intent.putExtra(PortalActivity.EXTRA_ID, String.valueOf(portal.getId()));
                    intent.putExtra(PortalActivity.EXTRA_TITLE, portal.getTitle());
                    startActivityForResult(intent, EDIT_PORTAL_REQUEST);
                }

            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == EDIT_PORTAL_REQUEST && resultCode == RESULT_OK) {
            int id = data.getIntExtra(PortalActivity.EXTRA_ID, -1);
            if (id == -1) {
                Toast.makeText(this, "Portal can't be updated", Toast.LENGTH_SHORT).show();
                return;
            } else {
                String title = data.getStringExtra(PortalActivity.EXTRA_TITLE);
                Portal portal = new Portal(title);
                portal.setId(id);
                portalView.update(portal);
                Toast.makeText(this, "Portal updated", Toast.LENGTH_SHORT).show();
            }

        } else {

            Toast.makeText(this, "Portal not saved", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.portal_ui_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.delete_all_portals:
                portalView.deleteAllPortals();
                Toast.makeText(this, "All portals deleted", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
