package edu.bu.metcs.portal;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class PortalActivity extends AppCompatActivity {
    public static final int EDIT_ASSOC_PROJECT_REQUEST = 2;
    public static final String EXTRA_ID = "edu.bu.metcs.portal.EXTRA_ID";
    public static final String EXTRA_TITLE = "edu.bu.metcs.portal.EXTRA_TITLE";

    public static int portalId;
    private int numOfAssociatedProjectss = 0;
    private ProjectView projectView;
    private RecyclerView associatedProjects;

    private EditText editTextTitle;
    private PortalView portalView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_portal);

        editTextTitle = findViewById(R.id.edit_title);

        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close);
        Intent intent = getIntent();


        if (intent.hasExtra(EXTRA_ID)) {
            setTitle("Edit Portal");
            editTextTitle.setText(intent.getStringExtra(EXTRA_TITLE));


            /*Associated course descriptions*/
            associatedProjects = findViewById(R.id.associated_projects_recylerview);
            associatedProjects.setLayoutManager(new LinearLayoutManager(this));
            associatedProjects.setHasFixedSize(true);
            final ProjectAdapter projectAdapter = new ProjectAdapter();
            associatedProjects.setAdapter(projectAdapter);
            projectView = ViewModelProviders.of(this).get(ProjectView.class);
            portalId = Integer.parseInt(intent.getStringExtra(EXTRA_ID));
            projectView.getAllAssociatedProjects(portalId).observe(this, new Observer<List<Project>>() {
                @Override
                public void onChanged(@Nullable List<Project> projects) {
                    numOfAssociatedProjectss = projects.size();
                    projectAdapter.submitList(projects);
                }
            });


            new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
                @Override
                public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                    return false;
                }

                @Override
                public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                    projectView.delete(projectAdapter.getProjectAt(viewHolder.getAdapterPosition()));
                }
            }).attachToRecyclerView(associatedProjects);


            projectAdapter.setOnItemClickedListner(new ProjectAdapter.OnItemClickedListner() {
                @Override
                public void onItemClicked(Project project) {
                    Intent intent = new Intent(PortalActivity.this, ProjectActivity.class);

                    intent.putExtra(ProjectActivity.EXTRA_PORTAL_ID, String.valueOf(project.getPortalId()));
                    intent.putExtra(ProjectActivity.EXTRA_PROJECT_ID, String.valueOf(project.getProjectId()));
                    intent.putExtra(ProjectActivity.EXTRA_PROJECT_TITLE, project.getProjectTitle());
                    intent.putExtra(ProjectActivity.EXTRA_PROJECT_DESCRIPTION, project.getProjectDescription());
                    intent.putExtra(ProjectActivity.EXTRA_ISFAVORITE, project.getIsFavorite());
                    intent.putExtra(ProjectActivity.EXTRA_KEYWORDS, project.getKeywords());
                    intent.putExtra(ProjectActivity.EXTRA_AUTHORS, project.getAuthors());
                    intent.putExtra(ProjectActivity.EXTRA_LINKS, project.getLink());
                  startActivityForResult(intent, EDIT_ASSOC_PROJECT_REQUEST);
                }
            });

            /*Associated project isFavorites*/

        } else {
            setTitle("Add Portal");
            editTextTitle.setText(intent.getStringExtra(EXTRA_TITLE));

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.portal_menu, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.save_portal:
                savePortal();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }


    private void savePortal() {

        portalView = ViewModelProviders.of(this).get(PortalView.class);
        Intent data = new Intent();

        String title = editTextTitle.getText().toString();


        if (title.trim().isEmpty()) {
            Toast.makeText(this, "Title is missing", Toast.LENGTH_SHORT);
            return;
        }

        Intent intent = getIntent();
        //Has portalId edit the Portal
        if (intent.hasExtra(EXTRA_ID)) {
            data.putExtra(EXTRA_TITLE, title);

            int id = Integer.valueOf(getIntent().getStringExtra(EXTRA_ID));
            if (id != -1) {
                data.putExtra(EXTRA_ID, id);

            }
            setResult(RESULT_OK, data);
            finish();

        } else { //Has no portalId so add new Portal
            Portal portal = new Portal(title);
            portalView.insert(portal);
            Toast.makeText(this, "Portal saved successfully", Toast.LENGTH_SHORT).show();
            finish();
            intent = new Intent(PortalActivity.this, PortalUI.class);
            startActivity(intent);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == EDIT_ASSOC_PROJECT_REQUEST && resultCode == RESULT_OK) {
            int id = data.getIntExtra(ProjectActivity.EXTRA_PROJECT_ID, -1);
            if (id == -1) {
                Toast.makeText(this, "Project wasn't updated", Toast.LENGTH_SHORT).show();
                return;
            } else {
                String portalId = data.getStringExtra((ProjectActivity.EXTRA_PORTAL_ID));
                int intPortalId = Integer.valueOf(portalId);
                String title = data.getStringExtra(ProjectActivity.EXTRA_PROJECT_TITLE);
                String description = data.getStringExtra(ProjectActivity.EXTRA_PROJECT_DESCRIPTION);
                String isFavorite = data.getStringExtra(ProjectActivity.EXTRA_ISFAVORITE);
                String keywords = data.getStringExtra(ProjectActivity.EXTRA_KEYWORDS);
                String authors = data.getStringExtra(ProjectActivity.EXTRA_AUTHORS);
                String link = data.getStringExtra(ProjectActivity.EXTRA_LINKS);
                Project project = new Project(intPortalId, title, description, isFavorite, keywords, authors, link);
                project.setProjectId(id);
                projectView.update(project);
                Toast.makeText(this, "Project updated", Toast.LENGTH_SHORT).show();
            }

        } else {

            Toast.makeText(this, "Project not saved", Toast.LENGTH_SHORT).show();
        }
    }

}
