package edu.bu.metcs.portal;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;

import java.util.ArrayList;

@Entity(tableName = "portals")
public class Portal {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String title;

    @Ignore
    public Portal() {
    }

    public Portal(String title) {
        this.title = title;

    }

    @Ignore
    public Portal(int id, String title) {
        this.id = id;
        this.title = title;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}
